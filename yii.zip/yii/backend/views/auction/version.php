<b>4,检查App版本接口</b>
<form action="?r=auction/versionupdate" method="post" target="_self">
emp_id:    <input name="version" value="" type="text">        <br>
token:	<input name="token" value="" type="text">        <br>
sort:<input name="sort" value="">               <br>
driver:<input name="driver" value="">     <br>
version:    <input name="version" value="" type="text">        <br>
<input name="submit" value="submit" type="submit">
</form>